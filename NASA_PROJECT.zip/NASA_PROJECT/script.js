$(window).ready(function () {

    var body = $("body"),
        universe = $("#universe"),
        solarsys = $("#solar-system");

    var init = function () {
        body.removeClass('view-2D opening').addClass("view-3D").delay(2000).queue(function () {
            $(this).removeClass('hide-UI').addClass("set-speed");
            $(this).dequeue();
        });
    };

    var setView = function (view) { universe.removeClass().addClass(view); };

    $("#toggle-data").click(function (e) {
        body.toggleClass("data-open data-close");
        e.preventDefault();
    });

    $("#toggle-controls").click(function (e) {
        body.toggleClass("controls-open controls-close");
        e.preventDefault();
    });

    $("#data a").click(function (e) {
        var ref = $(this).attr("class");
        solarsys.removeClass().addClass(ref);
        $(this).parent().find('a').removeClass('active');
        $(this).addClass('active');
        e.preventDefault();
    });

    $(".set-view").click(function () { body.toggleClass("view-3D view-2D"); });
    $(".set-zoom").click(function () { body.toggleClass("zoom-large zoom-close"); });
    $(".set-speed").click(function () { setView("scale-stretched set-speed"); });
    $(".set-size").click(function () { setView("scale-s set-size"); });
    $(".set-distance").click(function () { setView("scale-d set-distance"); });

    init();

   


    $(document).ready(function () {  
        const apiKey = '9WxtIgBfkomaB01aVZ5GiUaowW9EucV9NYZigwAd'; // Replace with your actual API key  
      
        // Fetch asteroids when the button is clicked  
        $('#fetch-asteroids').click(async () => {  
            const date = $('#date-input').val();  
            if (date) {  
                await fetchAsteroids(date);  
            } else {  
                alert("Please select a date.");  
            }  
        });  
      
        async function fetchAsteroids(date) {  
            const response = await fetch(`https://api.nasa.gov/neo/rest/v1/feed?start_date=${date}&end_date=${date}&api_key=${apiKey}`);  
              
            if (!response.ok) {  
                console.error('Error fetching data:', response.statusText);  
                return;  
            }  
      
            const data = await response.json();  
            displayAsteroids(data.near_earth_objects[date]);  
        }  
      
        function displayAsteroids(asteroids) {  
            const asteroidDataDiv = document.getElementById('asteroid-data');  
            asteroidDataDiv.innerHTML = ''; // Clear previous results  
      
            if (asteroids && asteroids.length > 0) {  
                asteroids.forEach(asteroid => {  
                    const row = document.createElement('tr');  
                      
                    // Create cells for each piece of data  
                    const nameCell = document.createElement('td');  
                    nameCell.textContent = asteroid.name;  
      
                    const diameterCell = document.createElement('td');  
                    diameterCell.textContent = `${asteroid.estimated_diameter.kilometers.estimated_diameter_min.toFixed(2)} - ${asteroid.estimated_diameter.kilometers.estimated_diameter_max.toFixed(2)}`;  
      
                    const missDistanceCell = document.createElement('td');  
                    missDistanceCell.textContent = asteroid.close_approach_data[0].miss_distance.kilometers;  
      
                    const closeApproachCell = document.createElement('td');  
                    closeApproachCell.textContent = asteroid.close_approach_data[0].close_approach_date;  
      
                    // Append cells to the row  
                    row.appendChild(nameCell);  
                    row.appendChild(diameterCell);  
                    row.appendChild(missDistanceCell);  
                    row.appendChild(closeApproachCell);  
      
                    // Append the row to the table body  
                    asteroidDataDiv.appendChild(row);  
                });  
            } else {  
                asteroidDataDiv.innerHTML = '<tr><td colspan="4">No asteroids found for this date.</td></tr>';  
            }  
        }  
    });  





    $(document).ready(function () {  
        const apiKey = '9WxtIgBfkomaB01aVZ5GiUaowW9EucV9NYZigwAd'; // Replace with your actual API key  
      
        // Set the default date to today  
        const today = new Date();  
        const formattedDate = today.toISOString().split('T')[0]; // Format: YYYY-MM-DD  
        $('#date-input').val(formattedDate);  
      
        // Fetch asteroids for today's date on page load  
        fetchAsteroids(formattedDate);  
      
        $('#fetch-asteroids').click(async () => {  
            const date = $('#date-input').val();  
            if (date) {  
                await fetchAsteroids(date);  
            } else {  
                alert("Please select a date.");  
            }  
        });  
      
        async function fetchAsteroids(date) {  
            const response = await fetch(`https://api.nasa.gov/neo/rest/v1/feed?start_date=${date}&end_date=${date}&api_key=${apiKey}`);  
              
            if (!response.ok) {  
                console.error('Error fetching data:', response.statusText);  
                return;  
            }  
      
            const data = await response.json();  
            displayAsteroids(data.near_earth_objects[date]);  
        }  
      
        function displayAsteroids(asteroids) {  
            const sliderContainer = document.getElementById('asteroid-slider');  
            sliderContainer.innerHTML = ''; // Clear previous results  
      
            if (asteroids && asteroids.length > 0) {  
                asteroids.forEach(asteroid => {  
                    const slide = document.createElement('div');  
                    slide.className = 'watch-card';  
      
                    // Placeholder image URL; replace with actual image source  
                    
      
                    slide.innerHTML = ` 
                         
                        <h1 >${asteroid.name}</h1>  
                        <div class="distance-block">  
                            <h2>Distance</h2>  
                            <h3>${asteroid.close_approach_data[0].miss_distance.kilometers} Km</h3>  
                        </div>  
                        <div class="diameter-text">  
                            <h2>Diameter</h2>
                            <h3>${asteroid.estimated_diameter.kilometers.estimated_diameter_max.toFixed(2)} m</h3>  
                            <h3>[estimated]</h3>  
                        </div>  
                    `;  
      
                    sliderContainer.appendChild(slide);  
                });  
            } else {  
                sliderContainer.innerHTML = '<div>No asteroids found for this date.</div>';  
            }  
        }  
    });  







    
    
    });  

